#
# Auto generated from POM project version.
# Please do not modify.
#
__version__="7.1.0.dev"
__java_version__="7.1.0-SNAPSHOT"
__scala_version__="2.12"
__delta_version__="3.2.0"
__hadoop_version__="3.3.4"
